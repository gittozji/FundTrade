package me.zji.config;

import org.springframework.context.annotation.Configuration;

/**
 * Spring 主配置
 * Created by imyu on 2017/1/18.
 */
@Configuration
public class RootConfig {

}
