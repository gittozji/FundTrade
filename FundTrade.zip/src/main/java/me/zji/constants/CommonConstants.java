package me.zji.constants;

/**
 * 一般常量
 * Created by imyu on 2017/2/23.
 */
public class CommonConstants {
    public static final int RESULT_SUCEESS = 1;
    public static final int RESULT_FAILURE = 0;
}
