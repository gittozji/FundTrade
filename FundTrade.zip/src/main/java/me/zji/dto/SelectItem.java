package me.zji.dto;

/**
 * 选择框的条目
 * Created by imyu on 2017/2/24.
 */
public class SelectItem {
    String item;
    String caption;

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public String getCaption() {
        return caption;
    }

    public void setCaption(String caption) {
        this.caption = caption;
    }
}
