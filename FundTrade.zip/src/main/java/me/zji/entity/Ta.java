package me.zji.entity;

/**
 * Ta
 * Created by imyu on 2017/3/1.
 */
public class Ta extends Id {
    String taCode;
    String taName;

    public String getTaCode() {
        return taCode;
    }

    public void setTaCode(String taCode) {
        this.taCode = taCode;
    }

    public String getTaName() {
        return taName;
    }

    public void setTaName(String taName) {
        this.taName = taName;
    }
}
