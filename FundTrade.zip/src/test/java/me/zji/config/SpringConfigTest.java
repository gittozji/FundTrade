package me.zji.config;

import static org.junit.Assert.*;

/**
 * Created by imyu on 2017/1/18.
 */
public class SpringConfigTest {

}